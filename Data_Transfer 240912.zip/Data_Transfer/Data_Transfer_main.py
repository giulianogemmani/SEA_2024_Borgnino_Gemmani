'''
Created on July 15, 2024

@author: MB
'''

import picture_transfer.Creator_PowerFactory as mainapp  # @UnresolvedImport


if __name__ == '__main__':  
    mainapp.run()
